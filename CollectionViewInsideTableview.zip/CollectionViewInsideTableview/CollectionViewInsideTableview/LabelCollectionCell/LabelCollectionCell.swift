//
//  LabelCollectionCell.swift
//  CollectionViewInsideTableview
//
//  Created by Nirav Joshi on 05/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class LabelCollectionCell: UICollectionViewCell {
    @IBOutlet weak var lblNumber: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
