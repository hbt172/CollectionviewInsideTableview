//
//  TableViewCell.swift
//  CollectionViewInsideTableview
//
//  Created by Nirav Joshi on 05/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
protocol ChangeColor {
    func  GetLabelBackground(color : UIColor,string : String);
}

class TableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource  {
    
    
    var colorDelegate : ChangeColor?
    var aryCVdata = NSMutableArray()
    @IBOutlet weak var cvImage: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        cvImage.register(UINib.init(nibName: "LabelCollectionCell", bundle: Bundle.main), forCellWithReuseIdentifier: "LabelCollectionCell")
        cvImage.delegate = self
        cvImage.dataSource = self
        cvImage.reloadData()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return aryCVdata.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : LabelCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "LabelCollectionCell", for: indexPath) as! LabelCollectionCell
        cell.lblNumber.text =  (aryCVdata[indexPath.row] as! String)
        if indexPath.row % 2 == 0 {
            cell.lblNumber.backgroundColor = UIColor.gray
        }
        else{
            cell.lblNumber.backgroundColor = UIColor.blue
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cell : LabelCollectionCell = collectionView.cellForItem(at: indexPath)! as! LabelCollectionCell
        colorDelegate?.GetLabelBackground(color: cell.lblNumber.backgroundColor!, string: aryCVdata[indexPath.row] as! String)
    }
    
}

extension TableViewCell: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
            let cellSize:CGSize = CGSize(width: self.frame.width / 3, height: self.frame.width / 3)
            return cellSize
        
    }
}
