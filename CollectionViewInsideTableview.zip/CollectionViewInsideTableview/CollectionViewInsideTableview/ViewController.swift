//
//  ViewController.swift
//  CollectionViewInsideTableview
//
//  Created by Nirav Joshi on 05/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,ChangeColor {
   
    
    
    @IBOutlet weak var viewColor: UIView!
    
    var aryTable = [["1asd","2dsad","sad3","1asd","2dsad","sad3"],["ads11","22sad","33asd"],["111asd","22asd2","33asd3"],["111asd1","22asd22","33ads33"],["1asd","2dsad","sad3","1asd","2dsad","sad3"],["ads11","22sad","33asd"],["111asd","22asd2","33asd3"],["111asd1","22asd22","33ads33"]]
    
    @IBOutlet weak var tblViewWithCV: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblViewWithCV.register(UINib.init(nibName: "TableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "TableViewCell")
        tblViewWithCV.estimatedRowHeight = 88.0
        tblViewWithCV.rowHeight = UITableView.automaticDimension
        tblViewWithCV.reloadData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryTable.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        
//        cell.myView.backgroundColor = self.colors[indexPath.row]
//        cell.myCellLabel.text = self.animals[indexPath.row]
        cell.aryCVdata.addObjects(from: aryTable[indexPath.row])
        cell.colorDelegate = self
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.view.frame.width / 3
    }
    
    func GetLabelBackground(color: UIColor, string: String) {
        viewColor.backgroundColor = color
        print(string)
    }
    
}

